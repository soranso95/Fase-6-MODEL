module FintechSystem {
    requires java.sql;
    requires java.servlet;
}
