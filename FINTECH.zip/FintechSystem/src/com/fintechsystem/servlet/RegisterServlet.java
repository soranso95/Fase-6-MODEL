package com.fintechsystem.servlet;

public class RegisterServlet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
