package com.fintechsystem.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {
    private static final String URL = "jdbc:oracle:thin:@oracle.fiap.com.br:1521/ORCL";
    private static final String USER = "RM553302";
    private static final String PASSWORD = "030691";

    static {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void main(String[] args) {
        try {
            Connection conn = getConnection();
            System.out.println("Conexão estabelecida com sucesso!");
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
