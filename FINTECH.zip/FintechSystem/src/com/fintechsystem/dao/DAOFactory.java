package com.fintechsystem.dao;

public class DAOFactory {
    public static UsuarioDAO getUsuarioDAO() {
        return new UsuarioDAO();
    }

    // Métodos para outros DAOs
}
